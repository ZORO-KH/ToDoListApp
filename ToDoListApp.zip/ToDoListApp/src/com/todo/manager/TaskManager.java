package com.todo.manager;



import com.todo.model.Task;
import com.todo.model.ToDoList;

/**
 * Manages task operations, interacting with ToDoList.
 */
public class TaskManager {
    private ToDoList toDoList;

    public TaskManager() {
        toDoList = new ToDoList();
    }

    public void addTask(String description, String dueDate) throws IllegalArgumentException {
        if (description == null || description.trim().isEmpty()) {
            throw new IllegalArgumentException("Task description cannot be empty!");
        }
        if (!dueDate.matches("\\d{4}-\\d{2}-\\d{2}")) {
            throw new IllegalArgumentException("Due date must be in YYYY-MM-DD format!");
        }
        Task task = new Task(description, dueDate);
        toDoList.addTask(task);
    }

    public void removeTask(int index) {
        toDoList.removeTask(index);
    }

    public void markTaskCompleted(int index) {
        toDoList.markTaskCompleted(index);
    }

    public Task[] getTasks() {
        return toDoList.getTasks();
    }
}