/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.todo.gui;

/**
 *
 * @author Pc
 */
import com.todo.manager.TaskManager;
import com.todo.model.Task;
import javax.swing.*;
import java.awt.*;


/**
 * Implements the GUI for the To-Do List application using Swing.
 */
public class GUI {
    private final TaskManager taskManager;
    private JFrame mainFrame;
    private JPanel mainPanel, addTaskPanel, viewTasksPanel;
    private JTextArea taskDisplay;

    public GUI() {
        taskManager = new TaskManager();
        initializeGUI();
    }

    private void initializeGUI() {
        // Main Frame
        mainFrame = new JFrame("To-Do List Application by [our team ]");
        mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        mainFrame.setSize(600, 400);
        mainFrame.setLayout(new CardLayout());

        // Main Menu Panel
        mainPanel = new JPanel();
        mainPanel.setLayout(new GridLayout(3, 1, 10, 10));
        JButton addTaskButton = new JButton("Add Task");
        JButton viewTasksButton = new JButton("View Tasks");
        JButton exitButton = new JButton("Exit");
        mainPanel.add(addTaskButton);
        mainPanel.add(viewTasksButton);
        mainPanel.add(exitButton);

        // Add Task Panel
        addTaskPanel = new JPanel();
        addTaskPanel.setLayout(new GridLayout(4, 2, 10, 10));
        JLabel descLabel = new JLabel("Task Description:");
        JTextField descField = new JTextField();
        JLabel dateLabel = new JLabel("Due Date (YYYY-MM-DD):");
        JTextField dateField = new JTextField();
        JButton saveButton = new JButton("Save Task");
        JButton backButton = new JButton("Back to Menu");
        addTaskPanel.add(descLabel);
        addTaskPanel.add(descField);
        addTaskPanel.add(dateLabel);
        addTaskPanel.add(dateField);
        addTaskPanel.add(saveButton);
        addTaskPanel.add(backButton);

        // View Tasks Panel
        viewTasksPanel = new JPanel();
        viewTasksPanel.setLayout(new BorderLayout());
        taskDisplay = new JTextArea(10, 30);
        taskDisplay.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(taskDisplay);
        JPanel buttonPanel = new JPanel();
        JTextField taskIndexField = new JTextField(5);
        JButton completeButton = new JButton("Mark Complete");
        JButton deleteButton = new JButton("Delete Task");
        JButton backButton2 = new JButton("Back to Menu");
        buttonPanel.add(new JLabel("Task Index:"));
        buttonPanel.add(taskIndexField);
        buttonPanel.add(completeButton);
        buttonPanel.add(deleteButton);
        buttonPanel.add(backButton2);
        viewTasksPanel.add(scrollPane, BorderLayout.CENTER);
        viewTasksPanel.add(buttonPanel, BorderLayout.SOUTH);

        // Add panels to frame
        mainFrame.add(mainPanel, "Main");
        mainFrame.add(addTaskPanel, "AddTask");
        mainFrame.add(viewTasksPanel, "ViewTasks");

        // Button actions
        addTaskButton.addActionListener(e -> showPanel("AddTask"));
        viewTasksButton.addActionListener(e -> {
            updateTaskDisplay();
            showPanel("ViewTasks");
        });
        exitButton.addActionListener(e -> {
            JOptionPane.showMessageDialog(mainFrame, "Thank you for using the To-Do List App!");
            System.exit(0);
        });

        saveButton.addActionListener(e -> {
            try {
                taskManager.addTask(descField.getText(), dateField.getText());
                JOptionPane.showMessageDialog(mainFrame, "Task added successfully!");
                descField.setText("");
                dateField.setText("");
            } catch (IllegalArgumentException ex) {
                JOptionPane.showMessageDialog(mainFrame, ex.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        backButton.addActionListener(e -> showPanel("Main"));
        backButton2.addActionListener(e -> showPanel("Main"));

        completeButton.addActionListener(e -> {
            try {
                int index = Integer.parseInt(taskIndexField.getText());
                taskManager.markTaskCompleted(index);
                updateTaskDisplay();
                taskIndexField.setText("");
            } catch (NumberFormatException | IndexOutOfBoundsException ex) {
                JOptionPane.showMessageDialog(mainFrame, "Invalid index!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        deleteButton.addActionListener(e -> {
            try {
                int index = Integer.parseInt(taskIndexField.getText());
                taskManager.removeTask(index);
                updateTaskDisplay();
                taskIndexField.setText("");
            } catch (NumberFormatException | IndexOutOfBoundsException ex) {
                JOptionPane.showMessageDialog(mainFrame, "Invalid index!", "Error", JOptionPane.ERROR_MESSAGE);
            }
        });

        // Show main menu
        showPanel("Main");
        mainFrame.setVisible(true);
    }

    private void showPanel(String panelName) {
        CardLayout cl = (CardLayout) mainFrame.getContentPane().getLayout();
        cl.show(mainFrame.getContentPane(), panelName);
    }

    private void updateTaskDisplay() {
        Task[] tasks = taskManager.getTasks();
        taskDisplay.setText("");
        for (int i = 0; i < tasks.length; i++) {
            taskDisplay.append(i + ": " + tasks[i].toString() + "\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(GUI::new);
    }
}
