package com.todo.model;





/**
 * Manages a list of tasks using an array.
 */
public class ToDoList {
    private Task[] tasks;
    private int size;
    private static final int MAX_TASKS = 100;

    public ToDoList() {
        tasks = new Task[MAX_TASKS];
        size = 0;
    }

    public void addTask(Task task) throws IllegalStateException {
        if (size >= MAX_TASKS) {
            throw new IllegalStateException("Task list is full!");
        }
        tasks[size] = task;
        size++;
    }

    public void removeTask(int index) throws IndexOutOfBoundsException {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Invalid task index!");
        }
        for (int i = index; i < size - 1; i++) {
            tasks[i] = tasks[i + 1];
        }
        tasks[size - 1] = null;
        size--;
    }

    public void markTaskCompleted(int index) throws IndexOutOfBoundsException {
        if (index < 0 || index >= size) {
            throw new IndexOutOfBoundsException("Invalid task index!");
        }
        tasks[index].setCompleted(true);
    }

    public Task[] getTasks() {
        Task[] currentTasks = new Task[size];
        for (int i = 0; i < size; i++) {
            currentTasks[i] = tasks[i];
        }
        return currentTasks;
    }

    public int getSize() { return size; }
}